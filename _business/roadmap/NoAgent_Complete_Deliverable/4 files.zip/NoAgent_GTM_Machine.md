# NoAgent — Go-To-Market Machine & Content Factory

## Prompt 4 Deliverable: Full GTM System for Launch & Scale

---

# 1. Programmatic SEO Page Templates

## 1.1 Architecture Overview

Programmatic SEO is NoAgent's primary organic acquisition channel. Every page is generated from structured data (area database, listing data, market statistics) combined with templates. Pages are rendered with Next.js ISR (Incremental Static Regeneration) — built at first request, cached at CDN, revalidated every 24 hours.

**URL hierarchy:**

```
noagent.com/
├── /sell-property-in/{area}                    # Area sell pages
├── /rent-out-property-in/{area}                # Area landlord pages
├── /sell-{property-type}-in/{area}             # Type × area pages
├── /property-for-sale-in/{area}                # Buyer area search pages
├── /property-to-rent-in/{area}                 # Tenant area search pages
├── /how-to-sell-a-{property-type}              # Guide pages
├── /how-to-sell-in-{area}                      # Area guide pages
├── /property/{slug}                            # Individual listing pages
├── /services/{service-type}/{area}             # Provider area pages
├── /blog/{slug}                                # Editorial content
└── /sold/{slug}                                # Completed sale case studies
```

## 1.2 Area Sell Page Template

**URL:** `/sell-property-in/{area}` (e.g., `/sell-property-in/clapham`)

**Data sources:**
- Area database (ONS + custom): name, parent area, lat/lng centroid, population, council, nearby areas
- Land Registry: sold prices (last 12 months), volume, price trends
- NoAgent listings: active count, recent completions, average days on market
- Google Keyword Planner: monthly search volume for "sell house in {area}"

### Page Fields

| Section | Field | Source | Purpose |
|---------|-------|--------|---------|
| **H1** | "Sell Your Property in {Area} Without an Agent" | Template + area DB | Primary keyword targeting |
| **Hero subtitle** | "Join {X} homeowners in {Area} who saved an average of £{Y} in agent fees" | NoAgent data (or estimated from 1.5% of avg area price) | Social proof + value prop |
| **CTA** | "Start Your Free Listing" → /register?intent=sell&area={slug} | Template | Conversion |
| **Market snapshot** | Average sold price: £{avg}, Price change (12m): {+/-X%}, Properties sold (12m): {count}, Average days to sell: {days} | Land Registry API | SEO content + trust |
| **Price band table** | Price bands (£0–250k, £250–500k, £500k–1m, £1m+) with count and avg price per band | Land Registry | Long-tail keyword capture + useful content |
| **How it works** | 4-step visual: List → Manage enquiries → Handle viewings → Close the deal | Template (static) | Conversion education |
| **Fee comparison** | "Traditional agent (1.5%): £{fee}. NoAgent: £{package_price}. You save: £{difference}" | Calculated from area avg price | Value prop |
| **Active listings** | Carousel of {3–6} active NoAgent listings in this area | NoAgent listing DB | Proof of activity + internal linking |
| **Recent sales** | "{X} properties sold through NoAgent in {Area}" with anonymised examples | NoAgent data (when available) | Social proof |
| **Nearby areas** | Links to 4–8 adjacent area pages | Area DB (geographic proximity) | Internal linking + crawlability |
| **Property type links** | "Sell a flat in {Area}" / "Sell a house in {Area}" / etc. | Template × area | Internal linking to type×area pages |
| **Area guide snippet** | 2–3 sentences about {Area}: transport links, character, buyer demand | Pre-written per area (top 200); AI-generated for long-tail | Content uniqueness |
| **FAQ** | 4–6 questions: "How much does it cost to sell in {Area}?", "How long does it take to sell in {Area}?", "Do I need an agent to sell in {Area}?" | Template with area-specific data injected | FAQ schema markup + long-tail |
| **Schema.org** | `LocalBusiness` + `FAQPage` + `BreadcrumbList` | Template | Rich snippets |
| **Meta title** | "Sell Your Property in {Area} Without an Agent | NoAgent" | Template | SERP click-through |
| **Meta description** | "List your {Area} property for free. Average {Area} home sells for £{avg}. Save £{fee} in agent fees. Professional tools, no commission." | Template + data | SERP click-through |
| **Canonical** | Self-referencing | Auto | Dedup |
| **Breadcrumb** | Home > Sell Property > {Region} > {Area} | Area DB hierarchy | Navigation + schema |

### Type × Area Variant

**URL:** `/sell-{type}-in/{area}` (e.g., `/sell-flat-in-clapham`)

Same template as above but filtered:
- H1: "Sell Your {Type} in {Area} Without an Agent"
- Market data filtered to property type
- Active listings filtered to type
- FAQ customised (e.g., "How much is a flat worth in {Area}?")

### Buyer/Tenant Search Pages

**URL:** `/property-for-sale-in/{area}`, `/property-to-rent-in/{area}`

| Section | Content |
|---------|---------|
| H1 | "Property for Sale in {Area}" / "Property to Rent in {Area}" |
| Listing grid | All active listings in area, sortable (price, date, beds) |
| Filters sidebar | Price, beds, type, features |
| Map view toggle | Mapbox/Google Maps with pins |
| Market stats | Same as sell page (buyer perspective) |
| Alert CTA | "Get notified when new properties are listed in {Area}" |
| Nearby areas | Links to adjacent area search pages |

## 1.3 Internal Linking Strategy

### Link Graph Architecture

```
Homepage
  ├── /sell-property-in/{region}  (12 UK regions)
  │     ├── /sell-property-in/{county}  (48 counties)
  │     │     ├── /sell-property-in/{town}  (~500 towns)
  │     │     │     ├── /sell-property-in/{neighbourhood}  (~3,000 neighbourhoods)
  │     │     │     │     ├── /sell-{type}-in/{neighbourhood}  (type variants)
  │     │     │     │     └── /property/{slug}  (individual listings)
  │     │     │     └── Nearby: sibling towns
  │     │     └── Nearby: sibling counties
  │     └── Nearby: sibling regions
  │
  ├── Same hierarchy for /rent-out-property-in/
  ├── Same hierarchy for /property-for-sale-in/
  ├── Same hierarchy for /property-to-rent-in/
  │
  ├── /how-to-sell-a-{type}  (guide pages, linked from type×area pages)
  ├── /how-to-sell-in-{area}  (area guides, linked from area pages)
  ├── /blog/{slug}  (editorial, contextually linked from area/guide pages)
  └── /sold/{slug}  (case studies, linked from area pages)
```

### Link Rules

1. **Every area page links to its parent region/county** (breadcrumb + body link).
2. **Every area page links to 4–8 nearby areas** (geographic adjacency, sidebar section).
3. **Every area page links to its type variants** ("Sell a flat in {Area}", "Sell a house in {Area}").
4. **Every area page links to the corresponding buyer/tenant search page** ("View properties for sale in {Area}").
5. **Every listing page links back to its area page** (breadcrumb + "More in {Area}" section).
6. **Every guide page links to relevant area pages** ("Ready to sell your leasehold flat? Start in {Area}").
7. **Blog posts contain 2–3 contextual links** to area pages or guide pages.
8. **Case study pages link to the area where the sale happened**.
9. **Footer**: top 20 areas by search volume, permanently linked.
10. **Sitemap**: dynamic XML sitemap regenerated daily, submitted to Google Search Console.

### Link Volume Targets (Launch)

| Page Type | Count at UK Launch | Growth Path |
|-----------|--------------------|-------------|
| Region sell pages | 12 | Static |
| County sell pages | 48 | Static |
| Town sell pages | ~500 | +50/month based on demand |
| Neighbourhood sell pages | ~3,000 | +200/month |
| Type × area pages | ~9,000 (3 types × 3,000 areas) | Scales with areas |
| Buyer search pages | Mirror sell pages | Scales with areas |
| Rental pages | Mirror sell pages | Scales with areas |
| Guide pages | 20 at launch | +4/month |
| Blog posts | 10 at launch | +8/month |
| Listing pages | Dynamic (scales with listings) | Core product |

---

# 2. Keyword Clusters (UK)

## 2.1 Methodology for Building Clusters

**Step 1: Seed terms.** Core actions (sell, rent, buy, let) × modifiers (without agent, no agent, privately, yourself, DIY, online, free) × property types (house, flat, property, home, apartment, bungalow) × locations.

**Step 2: Expand with tools.** Google Keyword Planner, Ahrefs/SEMrush keyword explorer, Google Search Console (once live), "People Also Ask," Google Autocomplete.

**Step 3: Cluster by intent.** Group keywords by user intent: Transactional (ready to act), Informational (researching), Navigational (looking for NoAgent specifically), Commercial Investigation (comparing options).

**Step 4: Map to pages.** Each cluster maps to a specific page template.

## 2.2 — 100 UK Keyword Clusters

### Cluster Group A: Sell Without Agent (Transactional) — 25 clusters

| # | Cluster Name | Representative Keywords | Monthly Volume (est.) | Target Page |
|---|-------------|------------------------|----------------------|-------------|
| 1 | Sell house no agent | sell house without estate agent, sell property without agent, sell home no agent fee | 4,400 | Homepage + /how-it-works |
| 2 | Sell house privately | sell house privately, sell home privately, private house sale | 3,600 | Homepage |
| 3 | Sell house yourself | sell house yourself, how to sell house yourself UK, DIY house sale | 2,900 | /how-to-sell-a-house |
| 4 | Sell house online | sell house online, sell property online, online house selling | 2,400 | Homepage |
| 5 | Sell house free | sell house for free, free house selling site, list house for free | 1,900 | /pricing |
| 6 | Sell flat without agent | sell flat without agent, sell apartment privately, flat for sale by owner | 1,600 | /how-to-sell-a-flat |
| 7 | Sell house fast | sell house fast, quick house sale, sell property quickly | 3,200 | Homepage (fast strategy) |
| 8 | List property yourself | list property yourself, list house yourself UK, self-list property | 1,300 | /how-it-works |
| 9 | Sell leasehold flat | sell leasehold flat, how to sell a leasehold property, leasehold sale process | 1,100 | /how-to-sell-a-leasehold-flat |
| 10 | Sell house no commission | no commission house sale, zero commission property sale, sell without paying agent | 880 | /pricing |
| 11 | Sell house {major city} | sell house London, sell house Manchester, sell house Birmingham (×20 cities) | 12,000 (aggregate) | /sell-property-in/{city} |
| 12 | Sell flat {major city} | sell flat London, sell flat Bristol, sell flat Edinburgh | 8,000 (aggregate) | /sell-flat-in/{city} |
| 13 | Sell house {town/area} | sell house Clapham, sell house Didsbury, sell house Headingley (×100 towns) | 15,000 (aggregate) | /sell-property-in/{area} |
| 14 | How much to sell house | how much does it cost to sell a house, selling fees UK, cost of selling house | 5,400 | /blog/cost-of-selling-guide |
| 15 | Estate agent fees | estate agent fees UK, how much do estate agents charge, average estate agent fee | 6,600 | /blog/estate-agent-fees-guide |
| 16 | Sell house save money | save money selling house, reduce selling costs, cheap way to sell house | 720 | Homepage + /pricing |
| 17 | Online estate agent | online estate agent, best online estate agent, online estate agent reviews | 8,100 | Homepage (competitor capture) |
| 18 | Purple Bricks alternative | alternative to Purplebricks, better than Purplebricks, Purplebricks competitor | 1,300 | /blog/purplebricks-alternative |
| 19 | Sell house no chain | sell house chain free, chain free property sale | 590 | /how-to-sell-a-house |
| 20 | Sell inherited house | sell inherited property, how to sell inherited house, selling deceased estate | 1,600 | /blog/selling-inherited-property |
| 21 | Sell buy-to-let property | sell rental property, sell buy to let, selling investment property | 1,300 | /blog/selling-buy-to-let |
| 22 | FSBO UK | for sale by owner UK, FSBO, owner selling property | 880 | Homepage |
| 23 | Sell house process UK | house selling process, steps to sell house UK, selling timeline | 2,400 | /how-to-sell-a-house |
| 24 | Sell shared ownership | sell shared ownership, selling shared ownership flat, shared ownership resale | 1,900 | /blog/selling-shared-ownership |
| 25 | Sell house with mortgage | sell house with mortgage, can I sell with outstanding mortgage | 1,600 | /blog/selling-with-mortgage |

### Cluster Group B: Rent Out / Landlord (Transactional) — 15 clusters

| # | Cluster Name | Representative Keywords | Monthly Volume (est.) | Target Page |
|---|-------------|------------------------|----------------------|-------------|
| 26 | Rent out property | rent out my property, rent out my house, how to rent out property | 3,600 | /landlords |
| 27 | Rent out without agent | rent out property without agent, let property yourself, DIY landlord | 1,300 | /landlords |
| 28 | Find tenants yourself | find tenants without agent, advertise property to rent, list property to rent | 1,100 | /landlords |
| 29 | Rent house {city} | rent out house London, let property Manchester | 6,000 (aggregate) | /rent-out-property-in/{city} |
| 30 | Tenant referencing | tenant referencing service, tenant credit check, reference a tenant | 2,400 | /services/referencing |
| 31 | Landlord fees | letting agent fees, landlord fees UK, cost of letting agent | 2,900 | /blog/letting-agent-fees |
| 32 | Tenancy agreement template | tenancy agreement template, AST template, free tenancy agreement | 4,400 | /blog/tenancy-agreement-guide |
| 33 | Deposit protection | deposit protection scheme, protect tenant deposit, DPS | 3,200 | /blog/deposit-protection-guide |
| 34 | Right to rent check | right to rent, right to rent check, landlord right to rent | 2,900 | /blog/right-to-rent-guide |
| 35 | EPC for rental | EPC for rental property, EPC requirement landlord, minimum EPC rental | 1,900 | /services/epc |
| 36 | Landlord insurance | landlord insurance, rental property insurance | 2,400 | /blog/landlord-insurance-guide |
| 37 | Section 21 notice | section 21, section 21 notice, eviction notice template | 5,400 | /blog/section-21-guide |
| 38 | Landlord responsibilities | landlord legal responsibilities, landlord obligations UK | 1,600 | /blog/landlord-responsibilities |
| 39 | HMO licence | HMO licence, houses in multiple occupation, HMO rules | 2,400 | /blog/hmo-guide |
| 40 | Rent out room | rent a room scheme, lodger agreement, spare room tax free | 2,900 | /blog/rent-a-room-guide |

### Cluster Group C: Buyer Intent (Transactional) — 15 clusters

| # | Cluster Name | Representative Keywords | Monthly Volume (est.) | Target Page |
|---|-------------|------------------------|----------------------|-------------|
| 41 | Property for sale {area} | property for sale Clapham, houses for sale Bristol, flats for sale Manchester | 50,000+ (aggregate) | /property-for-sale-in/{area} |
| 42 | Flats for sale {area} | flats for sale London, apartments for sale Edinburgh | 30,000+ (aggregate) | /property-for-sale-in/{area}?type=flat |
| 43 | Houses for sale {area} | houses for sale Leeds, houses for sale Brighton | 40,000+ (aggregate) | /property-for-sale-in/{area}?type=house |
| 44 | Buy direct from owner | buy property from owner, buy house direct, no agent property | 1,100 | /buyers |
| 45 | First time buyer {area} | first time buyer London, first time buyer help, starter homes {area} | 8,000 (aggregate) | /property-for-sale-in/{area} + filter |
| 46 | Property to rent {area} | flat to rent Clapham, house to rent Manchester | 60,000+ (aggregate) | /property-to-rent-in/{area} |
| 47 | Cheap property {area} | cheap houses for sale, affordable property {area}, budget homes | 12,000 (aggregate) | /property-for-sale-in/{area} + sort |
| 48 | New build {area} | new build homes {area}, new build flats, new developments | 15,000 (aggregate) | /property-for-sale-in/{area}?condition=new_build |
| 49 | Property near me | property for sale near me, houses near me, flats near me | 22,000 | /search (geolocation) |
| 50 | Buy house process | how to buy a house UK, buying process steps, house buying guide | 4,400 | /blog/buying-a-house-guide |
| 51 | Mortgage calculator | mortgage calculator, how much can I borrow, mortgage affordability | 40,000 | /tools/mortgage-calculator |
| 52 | Stamp duty calculator | stamp duty calculator, SDLT calculator, stamp duty rates | 27,000 | /tools/stamp-duty-calculator |
| 53 | Survey types | house survey types, homebuyer survey, building survey cost | 3,600 | /blog/survey-guide |
| 54 | Conveyancing | conveyancing solicitor, conveyancing fees, best conveyancer | 6,600 | /services/conveyancing |
| 55 | House viewing tips | what to look for viewing, house viewing checklist, questions to ask | 2,400 | /blog/viewing-checklist |

### Cluster Group D: Informational / Guide Content — 25 clusters

| # | Cluster Name | Representative Keywords | Monthly Volume (est.) | Target Page |
|---|-------------|------------------------|----------------------|-------------|
| 56 | How to sell house UK | step by step sell house, complete guide selling, selling process | 2,400 | /how-to-sell-a-house |
| 57 | How long to sell house | average time to sell, how long does selling take, time to sell house UK | 2,900 | /blog/how-long-to-sell |
| 58 | Best time to sell | best month to sell house, when to sell property, spring selling | 1,900 | /blog/best-time-to-sell |
| 59 | How to value house | how to value my house, house valuation, property value estimate | 6,600 | /tools/valuation-estimate |
| 60 | How to stage home | home staging tips, how to present house for sale, selling prep | 1,300 | /blog/home-staging-guide |
| 61 | Property photography tips | how to photograph house, property photography DIY, listing photos | 880 | /blog/photography-tips |
| 62 | Writing property description | how to write property description, listing copy tips, property advert | 590 | /blog/description-writing-guide |
| 63 | Offers on property | how to negotiate house price, accepting offers, best and final | 1,600 | /blog/offer-negotiation-guide |
| 64 | Gazumping | what is gazumping, how to avoid gazumping, gazumping protection | 2,400 | /blog/gazumping-guide |
| 65 | Exchange and completion | exchange of contracts, completion day, exchange to completion | 3,600 | /blog/exchange-completion-guide |
| 66 | Conveyancing process | conveyancing process explained, how long conveyancing, conveyancing steps | 2,900 | /blog/conveyancing-process |
| 67 | Property searches | property searches explained, local authority search, environmental search | 1,900 | /blog/property-searches-guide |
| 68 | EPC explained | what is EPC, EPC rating meaning, how to improve EPC | 3,600 | /blog/epc-guide |
| 69 | Leasehold vs freehold | leasehold vs freehold, what is leasehold, leasehold explained | 4,400 | /blog/leasehold-freehold-guide |
| 70 | Service charge explained | service charge flat, ground rent explained, leasehold charges | 2,400 | /blog/service-charge-guide |
| 71 | Capital gains tax property | CGT on property, capital gains selling house, CGT calculator | 6,600 | /blog/cgt-property-guide |
| 72 | Selling and buying same time | selling buying simultaneously, chain advice, bridging loan | 1,600 | /blog/selling-buying-chain |
| 73 | Power of attorney property | selling with power of attorney, POA property sale, LPA property | 1,100 | /blog/poa-selling-guide |
| 74 | Selling after divorce | selling house divorce, property settlement, joint ownership sale | 1,300 | /blog/selling-divorce-guide |
| 75 | Property auction | sell at auction, property auction guide, auction vs private sale | 2,400 | /blog/auction-guide |
| 76 | Rightmove listing | how to list on Rightmove, Rightmove without agent, Rightmove fees | 3,600 | /blog/portal-listing-guide |
| 77 | Zoopla listing | list on Zoopla, Zoopla without agent | 1,600 | /blog/portal-listing-guide |
| 78 | Property market forecast | UK property market 2026, house prices forecast, market predictions | 4,400 | /blog/market-outlook |
| 79 | Selling tenanted property | sell with tenants, selling buy to let with tenants, tenanted sale | 880 | /blog/selling-tenanted |
| 80 | Energy efficiency grants | home energy grant, ECO scheme, insulation grant | 3,600 | /blog/energy-efficiency-guide |

### Cluster Group E: Service / Provider Keywords — 10 clusters

| # | Cluster Name | Representative Keywords | Monthly Volume (est.) | Target Page |
|---|-------------|------------------------|----------------------|-------------|
| 81 | Property photographer {area} | property photographer London, real estate photography near me | 2,400 (aggregate) | /services/photography/{area} |
| 82 | EPC assessor {area} | EPC assessor near me, EPC certificate cost, book EPC | 3,600 (aggregate) | /services/epc/{area} |
| 83 | Floor plan service | property floor plan, floor plan for estate agent, floor plan cost | 1,100 | /services/floorplan |
| 84 | Conveyancing solicitor {area} | conveyancer near me, conveyancing quotes, cheap conveyancing | 6,600 (aggregate) | /services/conveyancing/{area} |
| 85 | Inventory clerk | inventory check in service, inventory clerk near me, rental inventory | 880 | /services/inventory |
| 86 | Home staging service | home staging company, property staging near me, staging cost | 720 | /services/staging |
| 87 | Removals {area} | removal company near me, house movers, moving company {area} | 8,000 (aggregate) | /services/removals/{area} |
| 88 | Property cleaning | end of tenancy cleaning, professional property cleaning | 3,600 | /services/cleaning |
| 89 | Mortgage broker {area} | mortgage advisor near me, mortgage broker free, independent mortgage advice | 6,600 (aggregate) | /services/mortgage/{area} |
| 90 | Virtual tour property | virtual tour service, 360 property tour, Matterport | 590 | /services/virtual-tours |

### Cluster Group F: Competitor / Comparison — 10 clusters

| # | Cluster Name | Representative Keywords | Monthly Volume (est.) | Target Page |
|---|-------------|------------------------|----------------------|-------------|
| 91 | Purplebricks review | Purplebricks review, is Purplebricks good, Purplebricks problems | 4,400 | /blog/purplebricks-review |
| 92 | Strike estate agent | Strike free estate agent, Strike review, Yopa alternative | 2,400 | /blog/strike-vs-noagent |
| 93 | Online agent comparison | best online estate agent, online agent comparison, online vs high street | 1,900 | /blog/online-agent-comparison |
| 94 | Tepilo / FSBO sites | Tepilo review, for sale by owner websites UK | 590 | /blog/fsbo-platforms-compared |
| 95 | Rightmove vs Zoopla | Rightmove vs Zoopla, best property portal, which portal to list on | 2,400 | /blog/portal-comparison |
| 96 | Estate agent vs online | estate agent vs online agent, do I need an agent, agent worth it | 1,600 | /blog/agent-vs-noagent |
| 97 | How to sell without Rightmove | sell without Rightmove, do I need Rightmove, Rightmove alternatives | 880 | /blog/selling-without-portals |
| 98 | OpenRent review | OpenRent review, OpenRent vs letting agent, OpenRent fees | 2,400 | /blog/openrent-vs-noagent |
| 99 | Best way to sell house 2026 | best way to sell house, most effective selling method, sell house tips 2026 | 1,900 | /blog/best-way-to-sell-2026 |
| 100 | No agent property sale | no agent house sale, agentless property sale, sell without middleman | 720 | Homepage |

## 2.3 Generalizable Method for Any Country

To replicate this keyword strategy in a new market:

**Step 1: Translate core seed terms.** Translate the 8 action phrases ("sell house without agent," "rent out property yourself," etc.) into the local language. Verify with native speaker that they are natural — literal translations often miss colloquial search terms. Check Google Trends for the market to find the dominant phrasing.

**Step 2: Map the location hierarchy.** Every country has an administrative geography. For the UK it is Region → County → Town → Neighbourhood. For the US: State → Metro → City → Neighbourhood. For Germany: Bundesland → Kreis → Stadt → Stadtteil. For France: Région → Département → Commune → Quartier. Build this into the area database.

**Step 3: Identify market-specific concerns.** Each market has unique legal/process keywords. UK: "leasehold," "stamp duty," "section 21," "EPC." US: "closing costs," "title insurance," "HOA," "MLS." Germany: "Grundbuch," "Notar," "Energieausweis," "Maklerprovision." France: "compromis de vente," "diagnostics immobiliers," "notaire." These become informational content clusters.

**Step 4: Identify local competitors.** Research the dominant online/hybrid agents in market. Build comparison clusters. UK: Purplebricks, Strike, Yopa. US: Redfin, Zillow, Opendoor. Germany: McMakler, Homeday. France: Proprioo, Hosman.

**Step 5: Validate volume with local tools.** Google Keyword Planner (set to target country + language). SEMrush/Ahrefs with country filter. Google Search Console data once pages are live.

**Step 6: Prioritise by volume × commercial intent.** Score each cluster: (Monthly Volume) × (Intent Score: Transactional=3, Commercial=2, Informational=1) = Priority Score. Build pages top-down.

---

# 3. Four-Week City Launch Sprint

## 3.1 Sprint Plan

**Target city for illustration:** Manchester (adaptable to any city).
**Team required:** 1 Marketing Lead, 1 Content Writer, 1 Developer (SEO page deployment), 1 Partnerships person (can be founder), 1 Customer Success (can be founder).

### Week –4 (Pre-Launch Prep)

| Day | Action | Owner | Deliverable |
|-----|--------|-------|-------------|
| M | Confirm Manchester area database complete (all neighbourhoods, postcodes, lat/lng) | Dev | Area DB seeded for Manchester metro |
| M | Pull Land Registry data for Manchester (sold prices, volumes, trends) | Dev | Data pipeline running |
| T | Deploy area sell pages for Manchester: 1 city + 8–12 neighbourhoods | Dev | Pages live with data |
| T | Deploy buyer search pages for Manchester | Dev | Pages live |
| W | Write area guide snippets for top 5 Manchester neighbourhoods (Didsbury, Chorlton, Northern Quarter, Ancoats, Sale) | Content | 5 unique snippets |
| W | Create Manchester-specific blog posts (×2): "How to sell your house in Manchester without an agent — 2026 guide" + "Manchester property market: what sellers need to know" | Content | 2 posts published |
| Th | Identify and shortlist 10 Manchester photographers, 5 EPC assessors, 3 conveyancers | Partnerships | Contact list |
| Th | Draft provider outreach emails (see Section 6) | Marketing | Templates ready |
| F | Send outreach to providers. Target: 3 photographers, 2 EPC assessors committed | Partnerships | Emails sent |
| F | Identify 5 "founding seller" candidates (personal network, property forums, social media) | Founder | Candidate list |

### Week –3 (Provider Onboarding + Founding Sellers)

| Day | Action | Owner | Deliverable |
|-----|--------|-------|-------------|
| M | Follow up provider outreach. Onboard first committed providers (profile setup, test job) | Partnerships | ≥2 providers onboarded |
| T | Outreach to founding sellers: personal calls/emails. Offer free Premium package + featured listing | Founder | ≥3 sellers committed |
| W | Help founding sellers create listings (hands-on, concierge-style). Book photography if needed | CS | ≥2 listings in draft |
| Th | Set up Google Ads campaign (Manchester keywords, £50/day initial budget). Ad groups: "sell house Manchester no agent," "sell flat Manchester," "sell property yourself Manchester" | Marketing | Campaigns live in draft |
| F | Set up Facebook/Instagram retargeting pixel. Create 3 ad creative variants (see Section 4) | Marketing | Creatives ready |
| F | Prepare launch week social content calendar (7 days of posts) | Content | Calendar complete |

### Week –2 (Soft Launch)

| Day | Action | Owner | Deliverable |
|-----|--------|-------|-------------|
| M | Founding seller listings go live. Quality check: photos, description, pricing | CS | ≥3 listings published |
| M | Activate Google Ads | Marketing | Ads live |
| T | Share founding listings on social media (NoAgent accounts + ask founders to share) | Marketing | Posts live |
| T | Submit sitemap to Google Search Console. Request indexing of Manchester pages | Dev | Submitted |
| W | Monitor first enquiries. Ensure notification flow works. Support founding sellers in responding | CS | Enquiries tracked |
| W | Deploy landing page variant for Manchester (see Section 4) | Dev | Landing page live |
| Th | First provider job: book photographer for a founding seller's listing | CS + Partnerships | Job booked |
| Th | Post in Manchester property Facebook groups, Reddit r/manchester, Mumsnet local | Marketing | 5 posts |
| F | Weekly metrics check: page views, registrations, listings started, enquiries | Marketing | Dashboard review |
| F | Adjust Google Ads bids based on first-week data | Marketing | Bids optimised |

### Week –1 (Push + Optimise)

| Day | Action | Owner | Deliverable |
|-----|--------|-------|-------------|
| M | Local PR outreach: Manchester Evening News property desk, local property bloggers, podcasts | Marketing | 5 pitches sent |
| M | Create "sold in Manchester" social proof content (even if projected, e.g., "3 listings live, first viewing booked") | Content | Social posts |
| T | Email campaign to all Manchester-area registered users: "New listings in your area" | Marketing | Email sent |
| T | Ramp Google Ads budget to £100/day if CPA is within target | Marketing | Budget adjusted |
| W | Founding seller check-in: any viewing booked? Any support needed? | CS | Status update |
| Th | Launch Facebook/Instagram ads (retargeting + cold audience: Manchester homeowners 30–65) | Marketing | Ads live |
| F | End-of-sprint review: all KPIs assessed (see 3.2 below) | All | Sprint report |

### Week 0+ (Ongoing — Repeat Monthly)

- Continue provider recruitment (target 10 providers in Manchester within 60 days)
- Continue content creation (2 blog posts/month, Manchester-focused)
- Expand to adjacent areas (Stockport, Salford, Trafford) once Manchester has ≥10 active listings
- First completion → case study → "proof loop" content
- Referral program activation: founding sellers refer other sellers for listing credits

## 3.2 Sprint KPIs

| KPI | Target (Week 4) | Measurement |
|-----|-----------------|-------------|
| Area pages indexed (Google) | ≥80% of deployed pages | Google Search Console |
| Organic impressions (Manchester keywords) | ≥5,000 | Google Search Console |
| Organic clicks | ≥200 | Google Search Console |
| Paid clicks | ≥500 | Google Ads |
| Cost per click (paid) | ≤£1.50 | Google Ads |
| Website registrations (Manchester) | ≥50 | Product analytics |
| Listings started | ≥10 | Product analytics |
| Listings published | ≥5 | Product analytics |
| Enquiries generated | ≥15 | Product analytics |
| Viewings booked | ≥5 | Product analytics |
| Offers submitted | ≥1 | Product analytics |
| Service providers onboarded | ≥5 | Admin dashboard |
| Service jobs completed | ≥3 | Admin dashboard |
| Cost per registration (blended) | ≤£10 | Marketing spend / registrations |
| Net Promoter Score (founding sellers) | ≥8/10 | Direct feedback |

---

# 4. Ad Creatives & Landing Page Variants

## 4.1 Google Ads

### Campaign Structure

| Campaign | Ad Groups | Keywords (examples) | Match Type | Daily Budget |
|----------|-----------|-------------------|------------|-------------|
| Brand | NoAgent brand terms | noagent, no agent property, noagent.com | Exact + Phrase | £20 |
| Sell Generic | Sell without agent, Sell house yourself, Private sale | sell house without agent, sell property yourself, no agent house sale | Phrase + Broad Modified | £50 |
| Sell Location | Sell {city}, Sell {area} | sell house Manchester, sell flat Didsbury | Phrase | £50 |
| Rent Out | Rent out property, Let property yourself | rent out property without agent, let house yourself, find tenants | Phrase + Broad Modified | £30 |
| Competitor | Alternative to {competitor} | Purplebricks alternative, better than Strike | Exact + Phrase | £20 |

### Ad Copy Variants (Google Search Ads)

**Variant A: Fee Savings (Primary)**

Headline 1: Sell Your House — No Agent Fee
Headline 2: Save £{avg_fee} on Your {Area} Sale
Headline 3: List Free. Professional Tools Included.
Description 1: List your property in minutes. Handle enquiries, viewings, and offers with smart tools. Average seller saves £{fee}. No commission, ever.
Description 2: Verified listings. Guided workflow. Deal room to completion. Thousands saved. Start your free listing today.

**Variant B: Speed/Simplicity**

Headline 1: Sell Your {Area} Home in Weeks
Headline 2: No Agent. No Commission. No Hassle.
Headline 3: From Listing to Sold — All Online
Description 1: Professional listing tools, smart viewing scheduler, and offer management — all without paying agent commission. Start free today.
Description 2: {X} properties already listed in {Area}. Join homeowners selling smarter. Guided process from listing to completion.

**Variant C: Trust / Verification**

Headline 1: Sell Direct. Buyers Trust Verified Sellers.
Headline 2: Verified Listings. Real Transparency.
Headline 3: No Agent Needed. Full Support Included.
Description 1: Verify your identity and ownership for faster buyer confidence. Professional photos, floorplans, and a secure deal room included.
Description 2: Buyers prefer verified sellers. Get the ID Verified badge and stand out. List your property free on NoAgent.

## 4.2 Social Media Ad Creatives (Facebook / Instagram)

### Creative A: Fee Calculator (Carousel)

Slide 1: "Your house is worth £450,000" (attractive property image)
Slide 2: "An agent would charge you £6,750" (calculator visual)
Slide 3: "With NoAgent, you keep it all" (happy homeowner image)
Slide 4: "List free. Sell smart. Save thousands." (CTA: Start Your Listing)

### Creative B: Testimonial / Case Study (Video, 15s)

Scene 1 (3s): "I sold my flat in Didsbury in 23 days."
Scene 2 (4s): "No agent. Saved £5,400."
Scene 3 (4s): Walkthrough of the NoAgent dashboard (screen recording)
Scene 4 (4s): "Professional tools. Zero commission." Logo + CTA.

### Creative C: Problem/Solution (Static Image)

Image: Split screen — left: stressed person writing a cheque to an agent, right: same person relaxed, holding phone showing NoAgent dashboard.
Text overlay: "Stop paying thousands for something you can do yourself."
CTA: "List Your Property Free"

### Creative D: Landlord-Specific (Static)

Image: Property keys with a "Rented" tag.
Text overlay: "Find verified tenants without a letting agent. Save £{monthly_fee}/month."
CTA: "List Your Rental Free"

### Targeting Parameters

| Audience | Platform | Targeting | Budget Split |
|----------|----------|-----------|-------------|
| Cold — Homeowners | Facebook + Instagram | Age 30–65, Homeowners (interest-based), {City} radius 15km, Interest: property, Rightmove, Zoopla | 40% |
| Cold — Landlords | Facebook | Age 30–65, Interest: buy-to-let, landlord forums, property investment, {City} radius 25km | 20% |
| Retargeting — Site visitors | Facebook + Instagram | Visited noagent.com in last 30 days, did not register | 25% |
| Retargeting — Started listing | Facebook + Instagram | Started listing flow, did not publish. Custom audience from product event. | 15% |

## 4.3 Landing Page Variants

### Variant 1: "Calculator" Landing Page

**URL:** `/lp/how-much-could-you-save`

**Layout:**

1. H1: "How Much Could You Save by Selling Without an Agent?"
2. Interactive calculator: Enter property value → shows agent fee (1.5%) vs NoAgent cost → savings
3. Below calculator: "Start Your Free Listing" CTA
4. Social proof: "{X} homeowners have saved £{total} so far"
5. 3-step "How It Works" visual
6. Trust badges: "Verified Sellers," "Secure Deal Room," "No Hidden Fees"
7. FAQ section (3 questions)

**Use case:** Google Ads traffic for cost-related queries. Facebook cold audience.

### Variant 2: "Area" Landing Page

**URL:** `/sell-property-in/{area}` (the programmatic page IS the landing page)

Enhanced for paid traffic with:
- Sticky header CTA: "Start Your Free Listing in {Area}"
- Exit-intent popup: "Before you go — see how much you could save selling in {Area}"
- Above-the-fold fee comparison for {Area}

**Use case:** Google Ads location-specific campaigns.

### Variant 3: "Social Proof" Landing Page

**URL:** `/lp/sold-without-an-agent`

**Layout:**

1. H1: "Real Homeowners. Real Sales. No Agent Required."
2. Grid of 4–6 case study cards (property image, area, days to sell, amount saved)
3. CTA: "Join Them — Start Your Free Listing"
4. Video testimonial (30s)
5. "How It Works" section
6. Pricing comparison table
7. Final CTA

**Use case:** Retargeting audiences. Social media traffic.

### Variant 4: "Landlord" Landing Page

**URL:** `/lp/rent-out-your-property`

**Layout:**

1. H1: "Rent Out Your Property Without a Letting Agent"
2. Fee comparison: "Letting agent: 10% of rent/month. NoAgent: £{per_let_fee} per tenancy."
3. Key features: Verified tenants, Referencing built in, Tenancy agreements, Deposit protection
4. CTA: "List Your Rental Free"
5. How it works (4 steps)
6. Landlord-specific FAQ

**Use case:** Google Ads landlord campaigns. Facebook landlord audience.

---

# 5. Lifecycle Messaging — Full Sequence Library

## 5.1 Seller Sequences

### S-01: Welcome & Onboarding

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| S-01a | Registration (intent=sell) | Email | Immediate | "Welcome to NoAgent — Let's Get Your Property Listed" / Intro + 3-step guide + link to start listing | Start Your Listing |
| S-01b | Registration (intent=sell) | SMS | +1 hour | "Welcome to NoAgent! Start your free listing: {link}" | Link to /listings/new |

### S-02: Listing Abandonment

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| S-02a | Listing started, not published | Email | +24h | "Your Listing Is Almost Ready" / Shows progress (e.g., "70% complete"), what's missing, tips for completing | Continue Your Listing |
| S-02b | Listing started, not published | Email | +72h | "Need Help Finishing Your Listing?" / Offer to help (chat link), mention founding sellers who published | Get Help or Continue |
| S-02c | Listing started, not published | SMS | +5 days | "Your NoAgent listing is still waiting. Finish in 5 minutes: {link}" | Link to listing |
| S-02d | Listing started, not published | Email | +10 days | "Still Thinking About Selling?" / Educational: "3 mistakes sellers make when listing" + soft CTA | Read Guide + Continue |

### S-03: Post-Publish

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| S-03a | Listing published | Email | Immediate | "You're Live! Here's What to Do Next" / Share link (social buttons), set up viewing availability, upgrade to Pro | Share Your Listing |
| S-03b | Listing published | SMS | Immediate | "Your property is live on NoAgent! Share it: {link}" | Link to listing |
| S-03c | Listing published, 0 enquiries in 3 days | Email | +3 days | "Boost Your Listing's Visibility" / Tips: improve photos, adjust price, share on social, consider paid boost | Boost or Improve |
| S-03d | Listing published, 0 enquiries in 7 days | Email | +7 days | "Not Getting Enquiries? Here's Why" / Checklist: is price competitive? Are photos professional? Share link? | Get a Free Pricing Review |

### S-04: Enquiry Received

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| S-04a | First enquiry received | Email + SMS | Immediate | "You Have Your First Enquiry!" / Buyer name, verification status, message preview. "Quick responses lead to viewings." | Respond Now |
| S-04b | Enquiry, no seller response | SMS | +12h | "You have an unanswered enquiry. Buyers move fast — respond now: {link}" | Link to inbox |
| S-04c | Enquiry, no seller response | Email | +24h | "Don't Miss Out — Your Buyer Is Waiting" / Stats on response time vs conversion | Respond to Enquiry |

### S-05: Viewing Flow

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| S-05a | First viewing booked | Email | Immediate | "Viewing Confirmed!" / Date, time, buyer details (verification status). Tips for preparing. | View Preparation Guide |
| S-05b | Viewing in 24h | SMS | –24h | "Reminder: viewing tomorrow at {time}. Buyer: {name}. Prepare your home and be ready." | Confirm |
| S-05c | Post-viewing (no offer in 3d) | Email | +3 days | "How Did the Viewing Go?" / Prompt to check buyer feedback, mention offer CTA was sent to buyer | View Feedback |

### S-06: Offer Flow

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| S-06a | Offer received | Email + SMS | Immediate | "You've Received an Offer — £{amount}" / Offer details, strength score, buyer profile. Actions: accept, reject, counter | Review Offer |
| S-06b | Multiple offers received | Email | When 2nd+ offer arrives | "You Now Have {N} Offers" / Comparison table teaser. Use the offer dashboard. | Compare Offers |
| S-06c | Offer accepted | Email | Immediate | "Congratulations! Your Deal Room Is Ready" / Next steps: instruct solicitor, invite to deal room, milestone overview | Open Deal Room |

### S-07: Deal Room

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| S-07a | Deal room created | Email | Immediate | "Your Deal Room Is Set Up" / Overview of milestones, how to invite solicitor, document upload guide | Go to Deal Room |
| S-07b | Milestone stalled 14d | Email | Day 14 | "Your Transaction Needs Attention" / Which milestone is stalled, who is blocking, suggested next action | Nudge or Contact |
| S-07c | Completion confirmed | Email | Immediate | "Sold! Congratulations!" / Summary (price, days to completion, savings). Review prompt. Referral offer. Upsells (rent out old property, removals) | Leave a Review |

### S-08: Re-engagement

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| S-08a | Listing expired (90d, no sale) | Email | Day 90 | "Your Listing Has Expired" / Market update for area, pricing review, option to relist with fresh strategy | Relist Your Property |
| S-08b | No login in 30 days (active listing) | Email | Day 30 | "Your Listing Is Still Active" / Enquiry/viewing stats while away, any action needed | Check Your Dashboard |

## 5.2 Buyer Sequences

### B-01: Welcome

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| B-01a | Registration | Email | Immediate | "Welcome to NoAgent" / Set up search alerts, browse listings, become a Verified Buyer | Set Up Alerts |

### B-02: Search Alerts

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| B-02a | New listing matches saved search | Email | Within 1h | "New Property in {Area}: {title}" / Photo, price, beds, key features, verification status | View Listing |
| B-02b | Price reduction on saved listing | Email | Immediate | "Price Reduced: {title}" / Old price → new price. Seller motivation signal. | View Updated Listing |

### B-03: Engagement

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| B-03a | Enquiry sent, no response 48h | Email | +48h | "Still Waiting on {address}? Here Are Similar Properties" / 3 similar listings | Browse Alternatives |
| B-03b | Viewing confirmed | Email + SMS | Immediate | "Viewing Confirmed: {address}" / Date, time, directions, viewing checklist link | Add to Calendar |
| B-03c | Viewing in 24h | SMS | –24h | "Viewing tomorrow at {time}: {address}. Please confirm attendance: {link}" | Confirm |
| B-03d | Post-viewing, no offer in 7d | Email | +7d | "Still Thinking About {address}?" / Tips on making an offer, offer guide link | Make an Offer |
| B-03e | Offer accepted | Email | Immediate | "Your Offer Was Accepted!" / Next steps, Deal Room access, what to expect | Open Deal Room |

## 5.3 Landlord Sequences

Mirror seller sequences (S-01 through S-08) with rental-specific content:
- S-03 equivalent: "Your Rental Listing Is Live" → "Set up tenant referencing, prepare tenancy agreement"
- S-06 equivalent: "Application Received" → tenant details, referencing prompt
- S-07 equivalent: "Tenancy Set Up Complete" → deposit protected, inventory booked, move-in date

## 5.4 Provider Sequences

| # | Trigger | Channel | Delay | Subject / Content Summary | CTA |
|---|---------|---------|-------|--------------------------|-----|
| P-01a | Registration complete | Email | Immediate | "Welcome to the NoAgent Marketplace" / Complete profile, set pricing, add portfolio | Complete Your Profile |
| P-02a | Profile incomplete after 3 days | Email | +3d | "Finish Your Profile to Start Receiving Jobs" / What's missing, how many sellers are in their area | Complete Profile |
| P-03a | First job request | Email + SMS | Immediate | "New Job Request: {service_type} in {area}" / Details, respond within 4 hours | Accept or Decline |
| P-04a | Job delivered, awaiting confirmation | Email | +48h | "Your Delivery Is Awaiting Client Confirmation" / Reminder that completion triggers payout | Check Status |
| P-05a | Weekly payout | Email | Weekly | "Your NoAgent Earnings This Week: £{amount}" / Breakdown by job, pending payments, earnings dashboard link | View Dashboard |
| P-06a | First review received | Email | Immediate | "You Received a Review!" / Rating preview, encourage great service for more | View Review |

## 5.5 Transactional Notifications (Always-On)

These are not sequences but single-trigger notifications that fire throughout the platform lifecycle.

| Event | Email | SMS | Push (future) |
|-------|-------|-----|---------------|
| New enquiry received | Yes | Yes | Yes |
| Enquiry response received | Yes | No | Yes |
| Viewing booked | Yes | Yes | Yes |
| Viewing cancelled | Yes | Yes | Yes |
| Viewing reminder (24h) | No | Yes | Yes |
| Offer received | Yes | Yes | Yes |
| Offer counter-received | Yes | Yes | Yes |
| Offer accepted/rejected | Yes | Yes | Yes |
| Deal Room milestone updated | Yes | No | Yes |
| Deal Room document uploaded | Yes | No | No |
| Deal Room stakeholder invited | Yes | No | No |
| Deal Room stalled (14d nudge) | Yes | No | No |
| Deal Room completed | Yes | Yes | Yes |
| Application received (landlord) | Yes | Yes | Yes |
| Application decision (tenant) | Yes | Yes | Yes |
| Referencing complete (landlord) | Yes | No | Yes |
| Service job request (provider) | Yes | Yes | Yes |
| Service job delivered (client) | Yes | No | Yes |
| Payment succeeded | Yes | No | No |
| Payment failed | Yes | Yes | No |
| Payout processed (provider) | Yes | No | No |
| Account security alert (password change, new device) | Yes | Yes | Yes |
| Listing moderated (takedown/warning) | Yes | No | No |
| Review received | Yes | No | Yes |

---

# 6. Partner Channel Strategy & Outreach Scripts

## 6.1 Partner Types & Value Exchange

| Partner Type | What NoAgent Offers Them | What They Offer NoAgent | Revenue Model |
|-------------|-------------------------|------------------------|---------------|
| **Photographers** | Qualified leads (sellers who need photos), automated booking, payment handling, platform exposure | Professional listing media, improved listing quality, seller satisfaction | Take-rate (15–20% per job) or flat referral fee |
| **EPC Assessors** | Lead flow (legal requirement for sellers/landlords), instant booking | EPC certificates delivered to listing, compliance | Take-rate (15–20%) |
| **Floorplan Providers** | Lead flow, digital delivery to listing | Floor plans that increase buyer engagement | Take-rate (15–20%) |
| **Conveyancers / Solicitors** | Qualified leads (post-offer, high conversion), data pre-populated (reduces admin) | Legal completion of transactions, platform credibility | Referral fee (fixed per instruction) |
| **Mortgage Brokers** | Buyer leads (registered buyers with stated intent), AIP prompt | Buyer finance, faster transaction completion | Referral fee (per completed mortgage) |
| **Referencing Companies** | Landlord leads, automated API integration | Tenant screening, compliance, landlord confidence | Per-reference fee (pass-through + margin) |
| **Inventory / Check-in** | Landlord leads, booking integration | Move-in reports, dispute protection | Take-rate (15–20%) |
| **Removals / Cleaning** | Post-completion leads (high intent, known timeline) | Completed transaction, customer satisfaction | Referral fee or take-rate |
| **Portal Partners (Rightmove, Zoopla)** | Listing data feed (increases their inventory) | Buyer traffic, listing visibility for NoAgent sellers | Seller pays portal fee (NoAgent facilitates) or NoAgent absorbs in premium packages |

## 6.2 Outreach Strategy by Partner Type

### Tier 1: Photographers (highest priority — listing quality drives everything)

**Goal:** 3–5 photographers per launch city within first 2 weeks.

**Where to find them:**
- Google: "property photographer {city}"
- Instagram: #propertyphotography + location tag
- Existing directories: iPhotography, Bark, Checkatrade
- Facebook groups: "Property Photography UK"

**Outreach sequence:**

Email 1 (Day 0):

Subject: New lead channel for property photographers in {City}

Hi {Name},

I came across your work on {where you found them} — your {specific compliment about their portfolio} stood out.

I'm building NoAgent, a platform where homeowners sell property without an agent. We're launching in {City} and need great photographers. Our sellers need professional photos but don't have an agent to arrange them — that's where you come in.

How it works: sellers book you directly through our platform. We handle scheduling, payment, and delivery. Your photos upload straight into the seller's listing. You set your own prices and availability.

For our first 5 photographers in {City}, we're waiving our platform fee for the first 10 jobs — so you keep 100% of what the seller pays.

Interested in a 10-minute call this week?

{Signature}

Email 2 (Day 3, if no reply):

Subject: Re: New lead channel for property photographers in {City}

Hi {Name},

Just following up — I know inboxes are busy.

Quick summary: free leads from homeowners selling their property in {City}, you keep 100% for your first 10 jobs, and we handle all the booking admin.

Worth a quick chat?

{Signature}

Email 3 (Day 7, if no reply):

Subject: Last one from me — photographer partnership in {City}

Hi {Name},

Final note — we're onboarding our launch photographers this week. If the timing isn't right, no worries at all. But if you're interested in a new source of property photography clients with no upfront cost, I'd love a quick call.

{Signature}

### Tier 2: Conveyancers / Solicitors

**Goal:** 2–3 conveyancing firms per launch city.

**Where to find them:**
- Law Society Find a Solicitor
- Google: "conveyancing solicitor {city}"
- Comparison sites: reallymoving, Compare My Move
- LinkedIn: search "conveyancer" + location

**Outreach email:**

Subject: Qualified conveyancing instructions from a new property platform

Dear {Name},

I'm reaching out from NoAgent, a new platform where homeowners sell and rent property without an estate agent. We're launching in {City} next month and are looking for trusted conveyancing partners.

When a seller on NoAgent accepts an offer, they need a solicitor. Currently they either have one already or we recommend one from our marketplace. We'd like to feature your firm.

What you'd get: pre-qualified instructions from sellers who have an accepted offer (not speculative leads). Listing data, buyer data, and offer terms are pre-populated in our Deal Room — reducing your admin.

Our model: we charge a flat referral fee of £{fee} per completed instruction (paid on completion, not instruction). No upfront cost.

Would you be open to a short call to discuss?

{Signature}

### Tier 3: EPC Assessors

Same approach as photographers, adapted for EPC. Key message: "Sellers and landlords on our platform legally need an EPC. We send them directly to you."

### Tier 4: Mortgage Brokers

**Outreach message (LinkedIn or email):**

Subject: Buyer leads from a new property platform

Hi {Name},

NoAgent is a property platform where buyers register, verify their identity, and submit offers directly to sellers. Many of our registered buyers need mortgage advice.

We're looking for trusted mortgage brokers to recommend to buyers on our platform. When a buyer indicates they need mortgage advice (during registration or the offer process), we'd connect them with you.

Model: referral fee per completed mortgage, or free for now while we build volume — your call.

Interested?

{Signature}

## 6.3 Partner Activation & Retention

### Onboarding Checklist (All Partners)

1. Sign partner agreement (terms, commission/fee structure, SLA)
2. Complete platform registration + business verification
3. Set up profile (bio, portfolio, service areas, pricing, availability)
4. Test job walkthrough (NoAgent team creates test booking, partner completes it)
5. Go-live confirmation

### Partner SLAs

| Metric | Target | Consequence of Miss |
|--------|--------|---------------------|
| Response to job request | Within 4 hours | Warning at 3 misses; deprioritised after 5 |
| Delivery timeline (photos/floorplan) | Within 48 hours of visit | Warning; customer refund option after 72h |
| Client rating | ≥4.0 average | Below 3.5 for 30 days → review → possible suspension |
| Dispute rate | <5% | Above 10% → review → possible suspension |

### Partner Retention Levers

- **Volume growth:** As platform grows, partners get more jobs without marketing spend.
- **Priority placement:** Top-rated partners featured first in marketplace. "Featured Provider" badge.
- **Tools:** Booking management dashboard, earnings analytics, automated invoicing.
- **Community:** Quarterly partner roundtable (virtual). Feedback loop on platform improvements.
- **Performance bonuses:** Partners maintaining ≥4.8 rating and ≥95% on-time for 3 months → reduced platform fee (5% instead of 15%).

## 6.4 Provider-to-Seller Referral Loop

This is a critical growth loop. Providers interact with homeowners regularly (photographers visit properties, EPC assessors inspect homes). Many of these homeowners are thinking about selling.

**Mechanic:**
- Provider shares a unique referral link or code.
- When a homeowner registers via that link and publishes a listing, the provider earns a credit (e.g., £50 credit toward reduced platform fees, or cash payout).
- Provider is also first-recommended for photography/EPC on that listing (natural loop).

**Enablement:**
- Provider gets a shareable referral card (physical and digital): "Thinking of selling? List your property free on NoAgent. Use code {CODE} for £XX off professional photos."
- Dashboard tracks referral conversions and earnings.
- Quarterly "top referrer" recognition (badge + bonus).

## 6.5 Portal Partnership Strategy (Rightmove, Zoopla)

Portals are the primary discovery channel for UK buyers. Seller access to portals is a key acquisition lever for NoAgent.

**Phase 1 (Pre-portal):** Sellers share listings on social media + NoAgent marketplace. Position: "You don't need Rightmove to sell. But if you want it, upgrade to our Pro package."

**Phase 2 (Portal integration):** Apply for data feed agreements with Rightmove and Zoopla. Requirements: minimum listing volume, data quality standards, compliance with portal terms.

**Technical integration:** Build listing export in BLM format (Rightmove) and RTDF (Zoopla). Export runs as a scheduled job — new/updated/withdrawn listings synced every 15 minutes.

**Seller offering:** "List on Rightmove + Zoopla" available in Pro and Premium packages. Portal fees (if any) passed through to seller transparently, or absorbed in package price.

**Phase 3 (Scale):** As NoAgent marketplace traffic grows, portal dependency reduces. Sellers increasingly find buyers directly through NoAgent. Portal listing becomes a nice-to-have rather than essential.

---

*End of NoAgent GTM Machine & Content Factory*

*Companion documents: End-State Spec (Prompt 1), Build Plan (Prompt 2), Security Review (Prompt 3)*
